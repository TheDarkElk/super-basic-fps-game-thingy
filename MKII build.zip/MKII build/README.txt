To actually play the game, double click on the exe, windows defender MAY block it, but its unlikely, if it does block it just allow it, this is a game, not malware or any of that crap.
default controls are WASD,    W= forward A= left S= back D= right
left click to shoot.
again this is a testing thing so theres not much to do.
IMPORTANT: as of current the game doesnt have a way to exit, so just Press ALT and F4 at the same time to exit
